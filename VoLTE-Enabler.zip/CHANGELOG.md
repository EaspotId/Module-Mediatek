## v1.0.0 - 2024-03-19
- Initial release
