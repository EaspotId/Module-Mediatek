#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Function to display error messages
error() {
    echo "Error: $1" >&2
    exit 1
}

# Function to check if the audio device is available
check_audio_device() {
    if ! command -v amixer &> /dev/null; then
        error "Command 'amixer' not found. Make sure you have the appropriate audio control tool on your system."
    fi
}

# Function to set audio balance and bass
set_audio_settings() {
    local left_balance=$1
    local right_balance=$2
    local bass_level=$3
    amixer -c 0 sset "Master" "${left_balance}%,${right_balance}%" >/dev/null || error "Failed to set audio balance"
    amixer -c 0 sset "Master" "${bass_level}%" >/dev/null || error "Failed to set bass level"
    echo "Audio balance has been set: $left_balance% (left) and $right_balance% (right)"
    echo "Bass level has been set: $bass_level%"
}

# Function to check the valid range of values
check_range() {
    local val=$1
    local min=$2
    local max=$3
    if ! [[ "$val" =~ ^[0-9]+$ ]]; then
        error "Value must be an integer"
    fi
    if (( val < min || val > max )); then
        error "Value must be between $min and $max"
    fi
}

# Provide execute permission to post-fs-data.sh
chmod +x "$MODDIR/post-fs-data.sh" || error "Failed to give execute permission to post-fs-data.sh"

# Check if arguments are provided
if [ $# -ne 3 ]; then
    error "Usage: $0 <left balance> <right balance> <bass level>"
fi

# Store argument values
left_balance=$1
right_balance=$2
bass_level=$3

# Check if values are within the valid range
check_range "$left_balance" 0 100
check_range "$right_balance" 0 100
check_range "$bass_level" 0 100

# Check audio device availability
check_audio_device

# Set audio balance and bass
set_audio_settings "$left_balance" "$right_balance" "$bass_level"

# Run additional command
"$MODDIR/audio_balance.sh" 50 50 70
