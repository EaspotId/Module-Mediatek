#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Function to display error messages
error() {
    echo "Error: $1" >&2
    exit 1
}

# Function to check if the audio device is available
check_audio_device() {
    if ! command -v amixer &> /dev/null; then
        error "Command 'amixer' not found. Make sure you have the appropriate audio control tool on your system."
    fi
}

# Function to set audio balance
set_audio_balance() {
    local left_balance=$1
    local right_balance=$2
    amixer -c 0 sset "Master" "${left_balance}%,${right_balance}%" >/dev/null || error "Failed to set audio balance"
    echo "Audio balance has been set: $left_balance% (left) and $right_balance% (right)"
}

# Function to check the valid range of values
check_range() {
    local val=$1
    local min=$2
    local max=$3
    if ! [[ "$val" =~ ^[0-9]+$ ]]; then
        error "Value must be an integer"
    fi
    if (( val < min || val > max )); then
        error "Value must be between $min and $max"
    fi
}

# Main script

# Check execution permission
if [ ! -x "$0" ]; then
    chmod +x "$0" || error "Failed to give execute permission to the script"
fi

# Check if arguments are provided
if [ $# -ne 2 ]; then
    error "Usage: $0 <left balance> <right balance>"
fi

# Store argument values
left_balance=$1
right_balance=$2

# Check if values are within the valid range
check_range "$left_balance" 0 100
check_range "$right_balance" 0 100

# Check audio device availability
check_audio_device

# Set audio balance
set_audio_balance "$left_balance" "$right_balance"

# Update configuration based on XML file
xml_file="AudioParamOptions_mgvi.xml"
if [ -f "$xml_file" ]; then
    num_speakers=$(grep "MTK_AUDIO_NUMBER_OF_SPEAKER" "$xml_file" | grep -oE '[0-9]+')
    num_mics=$(grep "MTK_AUDIO_NUMBER_OF_MIC" "$xml_file" | grep -oE '[0-9]+')
    echo "Number of speakers: $num_speakers"
    echo "Number of microphones: $num_mics"
else
    echo "XML file not found: $xml_file"
fi

